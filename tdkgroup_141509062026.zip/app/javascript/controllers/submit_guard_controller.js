import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  static values = {
    loadingText: String
  }

  connect() {
    this.submitted = false
  }

  submit(event) {
    if (this.submitted) {
      event.preventDefault()
      return
    }

    if (this.element.checkValidity && !this.element.checkValidity()) {
      return
    }

    const submitter = event.submitter

    window.setTimeout(() => {
      if (event.defaultPrevented) return

      this.submitted = true
      this.disableSubmitButtons(submitter)
    }, 0)
  }

  reset() {
    this.submitted = false
    this.submitButtons.forEach((button) => this.restoreButton(button))
  }

  disableSubmitButtons(submitter) {
    this.submitButtons.forEach((button) => {
      button.dataset.submitGuardWasDisabled = button.disabled ? "true" : "false"

      if (button === submitter) {
        this.applyLoadingState(button)
      }

      button.disabled = true
      button.setAttribute("aria-disabled", "true")
    })
  }

  applyLoadingState(button) {
    const loadingText = button.dataset.submitGuardLoadingText || this.loadingTextValue || "Working"

    if (button.tagName === "INPUT") {
      button.dataset.submitGuardOriginalValue = button.value
      button.value = loadingText
      return
    }

    button.dataset.submitGuardOriginalHtml = button.innerHTML
    button.classList.add("is-loading")
    button.replaceChildren(this.spinnerElement(), document.createTextNode(loadingText))
  }

  restoreButton(button) {
    if (button.dataset.submitGuardOriginalValue !== undefined) {
      button.value = button.dataset.submitGuardOriginalValue
      delete button.dataset.submitGuardOriginalValue
    }

    if (button.dataset.submitGuardOriginalHtml !== undefined) {
      button.innerHTML = button.dataset.submitGuardOriginalHtml
      delete button.dataset.submitGuardOriginalHtml
    }

    button.classList.remove("is-loading")
    button.removeAttribute("aria-disabled")

    if (button.dataset.submitGuardWasDisabled === "false") {
      button.disabled = false
    }

    delete button.dataset.submitGuardWasDisabled
  }

  spinnerElement() {
    const spinner = document.createElement("span")
    spinner.className = "submit-guard-spinner"
    spinner.setAttribute("aria-hidden", "true")
    return spinner
  }

  get submitButtons() {
    return Array.from(this.element.querySelectorAll("button[type='submit'], input[type='submit']"))
  }
}
